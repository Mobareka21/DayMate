function addTask() {

    var task = document.getElementById("taskInput").value;
    var time = document.getElementById("timeInput").value;
    var day = document.getElementById("dayInput").value;

    if (task == "") {
        alert("Please write a task!");
        return;
    }

    var newTask = document.createElement("p");

    newTask.innerHTML = "☐ " + task + " - " + time;

    newTask.onclick = function() {
        newTask.innerHTML = "☑ " + task + " - " + time;
        newTask.style.textDecoration = "line-through";
    };

    document.getElementById(day).appendChild(newTask);

    document.getElementById("taskInput").value = "";
    document.getElementById("timeInput").value = "";
}